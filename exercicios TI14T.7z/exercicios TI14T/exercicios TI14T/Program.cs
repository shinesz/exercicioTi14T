﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exercicios_TI14T
{
    class Program
    {
        static void Main(string[] args)
        {
            controlexercicicos control = new controlexercicicos();
            //Chamar o método que será utilizado
            control.executar();
            Console.ReadLine();
        }
    }
}
